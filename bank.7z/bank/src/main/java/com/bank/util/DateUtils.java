package com.bank.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    /**
     * 日期时间转换为字符串格式
     *
     * @param source  待处理的日期
     * @param pattern 转换的格式
     * @return
     */
    public static String dateToStr(Date source, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(source);
    }

    /**
     * 字符串转换为日期格式
     *
     * @param source  待处理的字符串
     * @param pattern 转换的格式
     * @return
     */
    public static Date strToDate(String source, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Date result = null;
        try {
            result = sdf.parse(source);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String longToStr(long source, String pattern) {
        return dateToStr(new Date(source), pattern);
    }

    public static Date currentDate() {
        return new Date();
    }


    public static String currentDateTimeStr() {
        return dateToStr(new Date(), "yyyyMMddHHmmss");
    }

    public static String currentYearStr() {
        return dateToStr(new Date(), "yyyy");
    }

    public static String currentYearMonthStr() {
        return dateToStr(new Date(), "yyyyMM");
    }

    public static String currentDateStr() {
        return dateToStr(new Date(), "yyyyMMdd");
    }

    public static long currentMillis() {
        return System.currentTimeMillis();
    }

    public static int currentSeconds() {
        return (int) (currentMillis() / 1000L);
    }

}
