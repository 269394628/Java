package com.bank.util;


public class AjaxResult {
    private int code;
    private String msg;
    private Object data;
    private Integer count;

    public AjaxResult(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public AjaxResult(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public AjaxResult(int code, String msg, Object data, Integer count) {
        this.code = code;
        this.msg = msg;
        this.data = data;
        this.count = count;
    }

    public static AjaxResult successResult() {
        return new AjaxResult(0, "success");
    }

    public static AjaxResult successResultForData(Object data) {
        return new AjaxResult(0, "success", data);
    }

    public static AjaxResult successResultForPage(Object data, int count) {
        return new AjaxResult(0, "success", data, count);
    }

    public static AjaxResult failResult(String message) {
        return new AjaxResult(-1, message);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
