package com.bank.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository("cardDao")
public interface CardDao {

    /**
     * 添加
     *
     * @param map
     * @return
     */
    int insert(Map<String, Object> map);

    /**
     * 修改
     *
     * @param map
     * @return
     */
    int update(Map<String, Object> map);

    /**
     * 判断卡号是否存在
     *
     * @param cardNo
     * @return
     */
    Integer getIdByNo(String cardNo);

    /**
     * 查询
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> list(Map<String, Object> map);

    /**
     * 统计
     *
     * @param map
     * @return
     */
    int count(Map<String, Object> map);

}
