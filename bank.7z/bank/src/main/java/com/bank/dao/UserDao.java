package com.bank.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository("userDao")
public interface UserDao {

    /**
     * 添加
     *
     * @param map
     * @return
     */
    int insert(Map<String, Object> map);

    /**
     * 修改
     *
     * @param map
     * @return
     */
    int update(Map<String, Object> map);

    /**
     * 查看个人信息
     *
     * @param map
     * @return
     */
    Map<String, Object> get(Map<String, Object> map);

    /**
     * 查询
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> list(Map<String, Object> map);

    /**
     * 统计
     *
     * @param map
     * @return
     */
    int count(Map<String, Object> map);

}
