package com.bank.dao;

import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository("loginDao")
public interface LoginDao {

    /**
     * 登录
     *
     * @param map
     * @return
     */
    Map<String, Object> login(Map<String, Object> map);

    /**
     * 添加
     *
     * @param map
     * @return
     */
    int insert(Map<String, Object> map);

    /**
     * 修改
     *
     * @param map
     * @return
     */
    int update(Map<String, Object> map);

}
