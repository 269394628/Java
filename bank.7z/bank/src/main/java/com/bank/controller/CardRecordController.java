package com.bank.controller;

import com.bank.service.CardRecordService;
import com.bank.service.CardService;
import com.bank.util.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/cardRecord")
public class CardRecordController {

    @Autowired
    CardRecordService cardRecordService;


    /**
     * 银行卡业务记录分页列表
     *
     * @param map
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping("/page")
    public AjaxResult page(@RequestParam Map<String, Object> map, @RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "limit", defaultValue = "10") int limit, HttpSession session) {
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        String role = user.get("role").toString();
        if ("2".equals(role)) {
            map.put("userId", user.get("id"));
        }
        List<Map<String, Object>> data = cardRecordService.listCardRecord(map, page, limit);
        int rows = cardRecordService.countCardRecord(map);
        return AjaxResult.successResultForPage(data, rows);
    }
}
