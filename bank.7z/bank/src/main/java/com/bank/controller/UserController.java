package com.bank.controller;

import com.bank.service.UserService;
import com.bank.util.AjaxResult;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    /**
     * 新增用户
     *
     * @param map
     * @return
     */
    @RequestMapping("/add")
    public AjaxResult addUser(@RequestParam Map<String, Object> map) {
        //#{account},#{password},#{role},#{state}
        //#{name},#{phone},#{addr},#{sex},#{idNo},#{userId},#{createTime}
        if (map.get("account") == null) {
            return AjaxResult.failResult("账号不能为空");
        }
        if (map.get("password") == null) {
            return AjaxResult.failResult("密码不能为空");
        }
        if (map.get("name") == null) {
            return AjaxResult.failResult("姓名不能为空");
        }
        if (map.get("phone") == null) {
            return AjaxResult.failResult("联系电话不能为空");
        }
        if (map.get("addr") == null) {
            return AjaxResult.failResult("地址不能为空");
        }
        if (map.get("sex") == null) {
            return AjaxResult.failResult("性别不能为空");
        }
        if (map.get("idNo") == null) {
            return AjaxResult.failResult("身份证号不能为空");
        }
        map.put("role", 2);
        map.put("state", 1);
        int i = userService.addUser(map);
        if (i <= 0) {
            return AjaxResult.failResult("新增用户失败");
        }
        return AjaxResult.successResult();
    }

    /**
     * 获取用户信息
     *
     * @param map
     * @return
     */
    @RequestMapping("/get")
    public AjaxResult getUser(@RequestParam Map<String, Object> map, HttpSession session) {
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("userId", user.get("id"));
        Map<String, Object> data = userService.getUser(map);
        return AjaxResult.successResultForData(data);
    }

    /**
     * 修改用户信息
     *
     * @param map
     * @return
     */
    @RequestMapping("/modify")
    public AjaxResult modifyUser(@RequestParam Map<String, Object> map) {
        userService.modifyUser(map);
        return AjaxResult.successResult();
    }


    /**
     * 用户分页列表
     *
     * @param map
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping("/page")
    public AjaxResult page(@RequestParam Map<String, Object> map, @RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "limit", defaultValue = "10") int limit) {
        List<Map<String, Object>> data = userService.listUser(map, page, limit);
        int rows = userService.countUser(map);
        return AjaxResult.successResultForPage(data, rows);
    }
}
