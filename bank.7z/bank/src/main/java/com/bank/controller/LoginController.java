package com.bank.controller;

import com.bank.service.LoginService;
import com.bank.util.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    LoginService loginService;

    /**
     * 登录
     *
     * @param session
     * @param map
     * @return
     */
    @RequestMapping("/login")
    @ResponseBody
    public AjaxResult login(HttpSession session, @RequestParam Map<String, Object> map) {
        if (map.get("account") == null) {
            return AjaxResult.failResult("账号不能为空");
        }
        if (map.get("password") == null) {
            return AjaxResult.failResult("密码不能为空");
        }
        Map<String, Object> user = loginService.login(map);
        if (user == null) {
            return AjaxResult.failResult("账号或密码错误");
        }
        session.setAttribute("user", user);
        return AjaxResult.successResultForData(user);
    }

    /**
     * 修改密码
     *
     * @param map
     * @return
     */
    @RequestMapping("/modifyPassword")
    @ResponseBody
    public AjaxResult modifyPassword(@RequestParam Map<String, Object> map, HttpSession session) {
        if (map.get("password") == null) {
            return AjaxResult.failResult("密码不能为空");
        }
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("id", user.get("id"));
        loginService.modifyPassword(map);
        return AjaxResult.successResult();
    }

    /**
     * 退出
     *
     * @param session
     * @param response
     * @throws IOException
     */
    @GetMapping("/logout")
    public void logout(HttpSession session, HttpServletResponse response) throws IOException {
        session.removeAttribute("user");
        response.sendRedirect("/bank/login.html");
    }

}
