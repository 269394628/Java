package com.bank.controller;

import com.bank.service.CardService;
import com.bank.util.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/card")
public class CardController {

    @Autowired
    CardService cardService;

    /**
     * 新开卡
     *
     * @param map
     * @return
     */
    @RequestMapping("/add")
    public AjaxResult addCard(@RequestParam Map<String, Object> map, HttpSession session) {
        //#{cardNo},#{cashOut},#{cashIn},#{userId},#{state},#{createTime}
        if (map.get("cardNo") == null) {
            return AjaxResult.failResult("卡号不能为空");
        }
        if (map.get("userId") == null) {
            return AjaxResult.failResult("卡所属用户不能为空");
        }
        if (cardService.exist(map.get("cardNo").toString())) {
            return AjaxResult.failResult("卡号已经存在");
        }
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("operateId", user.get("id"));
        map.put("cashOut", 0);
        map.put("cashIn", 0);
        map.put("state", 1);
        int i = cardService.addCard(map);
        if (i <= 0) {
            return AjaxResult.failResult("新开卡失败");
        }
        return AjaxResult.successResult();
    }

    /**
     * 存款
     *
     * @param map
     * @return
     */
    @RequestMapping("/cashIn")
    public AjaxResult cashIn(@RequestParam Map<String, Object> map, HttpSession session) {
        if (map.get("cardId") == null) {
            return AjaxResult.failResult("卡不能为空");
        }
        if (map.get("amount") == null) {
            return AjaxResult.failResult("存款金额不能为空");
        }
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("operateId", user.get("id"));
        int i = cardService.cashIn(map);
        if (i < 1) {
            return AjaxResult.failResult("存款失败");
        }
        return AjaxResult.successResult();
    }

    /**
     * 取款
     *
     * @param map
     * @return
     */
    @RequestMapping("/cashOut")
    public AjaxResult cashOut(@RequestParam Map<String, Object> map, HttpSession session) {
        if (map.get("cardId") == null) {
            return AjaxResult.failResult("卡不能为空");
        }
        if (map.get("amount") == null) {
            return AjaxResult.failResult("取款金额不能为空");
        }
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("operateId", user.get("id"));
        int i = cardService.cashOut(map);
        if (i < 1) {
            return AjaxResult.failResult("取款失败");
        }
        return AjaxResult.successResult();
    }

    /**
     * 转账
     *
     * @param map
     * @return
     */
    @RequestMapping("/transfer")
    public AjaxResult transfer(@RequestParam Map<String, Object> map, HttpSession session) {
        if (map.get("outCardId") == null) {
            return AjaxResult.failResult("转出卡不能为空");
        }
        if (map.get("inCardNo") == null) {
            return AjaxResult.failResult("对方卡号不能为空");
        }
        if (map.get("amount") == null) {
            return AjaxResult.failResult("转账金额不能为空");
        }
        if (!cardService.exist(map.get("inCardNo").toString())) {
            return AjaxResult.failResult("对方卡号不存在");
        }
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        map.put("operateId", user.get("id"));
        int i = cardService.transfer(map);
        if (i < 1) {
            return AjaxResult.failResult("转账失败");
        }
        return AjaxResult.successResult();
    }


    /**
     * 用户银行卡分页列表
     *
     * @param map
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping("/page")
    public AjaxResult page(@RequestParam Map<String, Object> map, @RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "limit", defaultValue = "10") int limit, HttpSession session) {
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");
        String role = user.get("role").toString();
        if ("2".equals(role)) {
            map.put("account", user.get("account"));
        }
        List<Map<String, Object>> data = cardService.listCard(map, page, limit);
        int rows = cardService.countCard(map);
        return AjaxResult.successResultForPage(data, rows);
    }
}
