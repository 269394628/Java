package com.bank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PageController {

    @RequestMapping(value = {"/", "/index.html"})
    public String defaultIndex() {
        return "index";
    }

    @RequestMapping("/login.html")
    public String login() {
        return "login";
    }

    @RequestMapping("/user.html")
    public String user() {
        return "user";
    }

    @RequestMapping("/card.html")
    public String card() {
        return "card";
    }

    @RequestMapping("/cardRecord.html")
    public String cardRecord() {
        return "cardRecord";
    }

    /**
     * 获取左侧菜单
     *
     * @param session
     * @return
     */
    @RequestMapping("/getMenu")
    @ResponseBody
    public Object getMenu(HttpSession session) {
        Map<String, Object> user = (Map<String, Object>) session.getAttribute("user");

        List<Map<String, Object>> menuList = new ArrayList<>();

        if ("1".equals(user.get("role").toString())) {
            Map<String, Object> menuMap1 = new LinkedHashMap<>();
            menuMap1.put("title", "用户管理");
            menuMap1.put("icon", "layui-icon-user");
            menuMap1.put("href", "/bank/user.html");
            menuMap1.put("spread", true);
            menuList.add(menuMap1);
        }

        Map<String, Object> menuMap2 = new LinkedHashMap<>();
        menuMap2.put("title", "银行卡管理");
        menuMap2.put("icon", "layui-icon-home");
        menuMap2.put("href", "/bank/card.html");
        menuMap2.put("spread", true);
        menuList.add(menuMap2);

        Map<String, Object> menuMap3 = new LinkedHashMap<>();
        menuMap3.put("title", "银行卡记录");
        menuMap3.put("icon", "layui-icon-user");
        menuMap3.put("href", "/bank/cardRecord.html");
        menuMap3.put("spread", true);
        menuList.add(menuMap3);

        return menuList;
    }


}
