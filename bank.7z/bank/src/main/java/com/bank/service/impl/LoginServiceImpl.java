package com.bank.service.impl;

import com.bank.dao.LoginDao;
import com.bank.service.LoginService;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

    @Autowired
    LoginDao loginDao;


    /**
     * 登录
     *
     * @param map
     * @return
     */
    @Override
    public Map<String, Object> login(Map<String, Object> map) {
        map.put("password", DigestUtils.md5Hex(map.get("password").toString()));
        return loginDao.login(map);
    }


    /**
     * 修改密码
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int modifyPassword(Map<String, Object> map) {
        map.put("password", DigestUtils.md5Hex(map.get("password").toString()));
        return loginDao.update(map);
    }
}
