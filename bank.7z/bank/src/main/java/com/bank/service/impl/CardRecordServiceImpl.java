package com.bank.service.impl;

import com.bank.dao.CardRecordDao;
import com.bank.service.CardRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service("cardRecordService")
public class CardRecordServiceImpl implements CardRecordService {

    @Autowired
    CardRecordDao cardRecordDao;

    /**
     * 新增卡业务记录
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int addCardRecord(Map<String, Object> map) {
        return cardRecordDao.insert(map);
    }

    /**
     * 查询卡业务记录
     *
     * @param map
     * @param page
     * @param limit @return
     */
    @Override
    public List<Map<String, Object>> listCardRecord(Map<String, Object> map, int page, int limit) {
        map.put("start", (page - 1) * limit);
        map.put("num", limit);
        return cardRecordDao.list(map);
    }

    /**
     * 统计卡业务记录
     *
     * @param map
     * @return
     */
    @Override
    public int countCardRecord(Map<String, Object> map) {
        return cardRecordDao.count(map);
    }
}
