package com.bank.service;

import java.util.Map;

public interface LoginService {
    /**
     * 登录
     *
     * @param map
     * @return
     */
    Map<String, Object> login(Map<String, Object> map);


    /**
     * 修改密码
     *
     * @param map
     * @return
     */
    int modifyPassword(Map<String, Object> map);
}
