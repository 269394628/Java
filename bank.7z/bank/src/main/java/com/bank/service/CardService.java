package com.bank.service;

import java.util.List;
import java.util.Map;


public interface CardService {

    /**
     * 新开卡
     *
     * @param map
     * @return
     */
    int addCard(Map<String, Object> map);


    /**
     * 存款
     *
     * @param map
     * @return
     */
    int cashIn(Map<String, Object> map);


    /**
     * 取款
     *
     * @param map
     * @return
     */
    int cashOut(Map<String, Object> map);


    /**
     * 转账
     *
     * @param map
     * @return
     */
    int transfer(Map<String, Object> map);

    /**
     * 判断卡号是否存在
     *
     * @param cardNo
     * @return
     */
    boolean exist(String cardNo);

    /**
     * 查询卡信息
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> listCard(Map<String, Object> map, int page, int limit);

    /**
     * 统计卡信息
     *
     * @param map
     * @return
     */
    int countCard(Map<String, Object> map);

}
