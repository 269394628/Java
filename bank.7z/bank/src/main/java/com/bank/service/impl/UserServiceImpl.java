package com.bank.service.impl;

import java.util.List;
import java.util.Map;

import com.bank.dao.LoginDao;
import com.bank.dao.UserDao;
import com.bank.service.UserService;
import com.bank.util.DateUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    UserDao userDao;

    @Autowired
    LoginDao loginDao;

    /**
     * 添加
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int addUser(Map<String, Object> map) {
        //1.添加用户登录账户
        map.put("password", DigestUtils.md5Hex(map.get("password").toString()));
        int i = loginDao.insert(map);
        if (i <= 0) {
            return -1;
        }
        map.put("createTime", DateUtils.currentSeconds());
        map.put("userId", map.get("id"));
        //2.添加用户基本信息
        int j = userDao.insert(map);
        if (j <= 0) {
            return -1;
        }
        return 1;
    }


    /**
     * 修改
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int modifyUser(Map<String, Object> map) {
        return userDao.update(map);
    }

    /**
     * 获取用户资料
     *
     * @param map
     * @return
     */
    @Override
    public Map<String, Object> getUser(Map<String, Object> map) {
        return userDao.get(map);
    }

    /**
     * 查询
     *
     * @param map
     * @return
     */
    @Override
    public List<Map<String, Object>> listUser(Map<String, Object> map, int page, int limit) {
        map.put("start", (page - 1) * limit);
        map.put("num", limit);
        return userDao.list(map);
    }

    /**
     * 统计
     *
     * @param map
     * @return
     */
    @Override
    public int countUser(Map<String, Object> map) {
        return userDao.count(map);
    }
}
