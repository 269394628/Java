package com.bank.service;

import java.util.List;
import java.util.Map;

public interface UserService {

    /**
     * 添加用户
     *
     * @param map
     * @return
     */
    int addUser(Map<String, Object> map);

    /**
     * 修改用户资料
     *
     * @param map
     * @return
     */
    int modifyUser(Map<String, Object> map);

    /**
     * 获取用户资料
     *
     * @param map
     * @return
     */
    Map<String, Object> getUser(Map<String, Object> map);

    /**
     * 分页列表查询用户
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> listUser(Map<String, Object> map, int page, int limit);

    /**
     * 统计查询用户
     *
     * @param map
     * @return
     */
    int countUser(Map<String, Object> map);

}
