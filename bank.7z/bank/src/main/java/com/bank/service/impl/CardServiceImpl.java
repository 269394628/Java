package com.bank.service.impl;

import com.bank.dao.CardDao;
import com.bank.dao.CardRecordDao;
import com.bank.service.CardService;
import com.bank.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("cardService")
public class CardServiceImpl implements CardService {

    @Autowired
    CardDao cardDao;

    @Autowired
    CardRecordDao cardRecordDao;

    /**
     * 新开卡
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int addCard(Map<String, Object> map) {
        //#{cardId},#{amount},#{type},#{userId},#{remark},#{createTime}
        map.put("createTime", DateUtils.currentSeconds());
        int i = cardDao.insert(map);
        if (i < 1) {
            return -1;
        }
        map.put("cardId", map.get("id"));
        map.put("amount", 0);
        map.put("type", 1);
        map.put("remark", "新开卡号:" + map.get("cardNo"));
        int j = cardRecordDao.insert(map);
        if (j < 1) {
            return -1;
        }
        return 1;
    }

    /**
     * 存款
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int cashIn(Map<String, Object> map) {
        map.put("id", map.get("cardId"));
        map.put("cashIn", map.get("amount"));
        int i = cardDao.update(map);
        if (i < 1) {
            return -1;
        }
        map.put("type", 2);
        map.put("remark", "存款金额:" + map.get("amount"));
        map.put("createTime", DateUtils.currentSeconds());
        int j = cardRecordDao.insert(map);
        if (j < 1) {
            return -1;
        }
        return 1;
    }

    /**
     * 取款
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int cashOut(Map<String, Object> map) {
        map.put("id", map.get("cardId"));
        map.put("cashOut", map.get("amount"));
        int i = cardDao.update(map);
        if (i < 1) {
            return -1;
        }
        map.put("type", 3);
        map.put("remark", "取款金额:" + map.get("amount"));
        map.put("createTime", DateUtils.currentSeconds());
        int j = cardRecordDao.insert(map);
        if (j < 1) {
            return -1;
        }
        return 1;
    }

    /**
     * 转账
     *
     * @param map
     * @return
     */
    @Override
    @Transactional
    public int transfer(Map<String, Object> map) {
        Object amount = map.get("amount");
        Map<String, Object> cardOutMap = new HashMap<>();
        cardOutMap.put("id", map.get("outCardId"));
        cardOutMap.put("cashOut", amount);
        int i = cardDao.update(cardOutMap);
        if (i < 1) {
            return -1;
        }
        //#{cardId},#{amount},#{type},#{operateId},#{remark},#{createTime}
        Map<String, Object> cardOutRecordMap = new HashMap<>();
        cardOutRecordMap.put("type", 5);
        cardOutRecordMap.put("amount", amount);
        cardOutRecordMap.put("cardId", map.get("outCardId"));
        cardOutRecordMap.put("operateId", map.get("operateId"));
        cardOutRecordMap.put("remark", "转出金额:" + amount);
        cardOutRecordMap.put("createTime", DateUtils.currentSeconds());
        int j = cardRecordDao.insert(cardOutRecordMap);
        if (j < 1) {
            return -1;
        }

        Integer inCardId = cardDao.getIdByNo(map.get("inCardNo").toString());
        Map<String, Object> cardInMap = new HashMap<>();
        cardInMap.put("id", inCardId);
        cardInMap.put("cashIn", amount);
        int k = cardDao.update(cardInMap);
        if (k < 1) {
            return -1;
        }
        Map<String, Object> cardInRecordMap = new HashMap<>();
        cardInRecordMap.put("type", 4);
        cardInRecordMap.put("amount", amount);
        cardInRecordMap.put("cardId", inCardId);
        cardInRecordMap.put("operateId", map.get("operateId"));
        cardInRecordMap.put("remark", "转入金额:" + amount);
        cardInRecordMap.put("createTime", DateUtils.currentSeconds());
        int m = cardRecordDao.insert(cardInRecordMap);
        if (m < 1) {
            return -1;
        }

        return 1;
    }

    /**
     * 判断卡号是否存在
     *
     * @param cardNo
     * @return
     */
    @Override
    public boolean exist(String cardNo) {
        return cardDao.getIdByNo(cardNo) != null;
    }

    /**
     * 查询卡信息
     *
     * @param map
     * @param page
     * @param limit @return
     */
    @Override
    public List<Map<String, Object>> listCard(Map<String, Object> map, int page, int limit) {
        map.put("start", (page - 1) * limit);
        map.put("num", limit);
        return cardDao.list(map);
    }

    /**
     * 统计卡信息
     *
     * @param map
     * @return
     */
    @Override
    public int countCard(Map<String, Object> map) {
        return cardDao.count(map);
    }
}
