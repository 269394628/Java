package com.bank.service;

import java.util.List;
import java.util.Map;

public interface CardRecordService {
    /**
     * 新增卡业务记录
     *
     * @param map
     * @return
     */
    int addCardRecord(Map<String, Object> map);

    /**
     * 查询卡业务记录
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> listCardRecord(Map<String, Object> map, int page, int limit);

    /**
     * 统计卡业务记录
     *
     * @param map
     * @return
     */
    int countCardRecord(Map<String, Object> map);
}
