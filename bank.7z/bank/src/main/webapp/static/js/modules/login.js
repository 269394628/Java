layui.use(['layer', 'form'], function () {
    var layer = layui.layer;
    var form = layui.form;
    var $ = layui.$;
    $("#login-btn").click(function () {
        $.ajax({
            url: '/bank/login',
            type: 'post',
            dataType: 'json',
            data: $("#login-form").serialize(),
            success: function (res) {
                if (res.code == -1) {
                    layer.msg(res.msg);
                } else {
                    sessionStorage.setItem("user", JSON.stringify(res.data));
                    window.top.location.href = "/bank/index.html";
                }
            }
        });
        return false;
    });

});