var card = {
    cashIn: function (d) {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#card-cashIn-form')
                , type: 1
                , title: '存款'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    $('#card-cashIn-form input[name="cardId"]').val(d.id);
                    form.render();
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        if (data.field.amount <= 0) {
                            layer.alert('存款金额不能小于0');
                            return false;
                        }
                        $.ajax({
                            url: '/bank/card/cashIn',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('存款成功', function (index) {
                                        location.reload();
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
    },
    cashOut: function (d) {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#card-cashOut-form')
                , type: 1
                , title: '取款'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    $('#card-cashOut-form input[name="cardId"]').val(d.id);
                    form.render();
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        if (data.field.amount <= 0) {
                            layer.alert('取款金额不能小于0');
                            return false;
                        }
                        if (data.field.amount > d.balance) {
                            layer.alert('取款金额不能大于卡的余额');
                            return false;
                        }
                        $.ajax({
                            url: '/bank/card/cashOut',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('取款成功', function (index) {
                                        location.reload();
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
    },
    transfer: function (d) {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#card-transfer-form')
                , type: 1
                , title: '取款'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    $('#card-transfer-form input[name="outCardId"]').val(d.id);
                    form.render();
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        if (data.field.amount <= 0) {
                            layer.alert('转账金额不能小于0');
                            return false;
                        }
                        if (data.field.amount > d.balance) {
                            layer.alert('转账金额不能大于卡的余额');
                            return false;
                        }
                        $.ajax({
                            url: '/bank/card/transfer',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('转账成功', function (index) {
                                        location.reload();
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
    }
};
layui.use(['layer', 'table', 'form'], function () {
    var table = layui.table;
    var form = layui.form;
    var $ = layui.$;
    var tableInit = table.render({
        elem: '#card'
        , url: '/bank/card/page'
        , method: 'post'
        , page: true
        , limits: [10, 15, 20]
        , cols: [[
            {field: 'cardNo', title: '卡号', sort: true, fixed: 'left'}
            , {field: 'cashOut', title: '累计出账'}
            , {field: 'cashIn', title: '累计入账'}
            , {field: 'balance', title: '账户余额'}
            , {field: 'account', title: '所属账号'}
            , {field: 'createTime', title: '开卡时间'}
            , {
                field: 'option', title: '操作', templet: function (d) {
                    var html = "";
                    var user = JSON.parse(sessionStorage.getItem("user"));
                    if (user.role == 1) {
                        html += '<button class="layui-btn layui-btn-sm layui-bg-blue" onclick="card.cashIn(' + JSON.stringify(d).replace(/"/g, '&quot;') + ');">存款</button>';
                        html += '<button class="layui-btn layui-btn-sm layui-bg-red" onclick="card.cashOut(' + JSON.stringify(d).replace(/"/g, '&quot;') + ');">取款</button>';
                        html += '<button class="layui-btn layui-btn-sm layui-bg-green" onclick="card.transfer(' + JSON.stringify(d).replace(/"/g, '&quot;') + ');">转账</button>';
                    } else {
                        html += '<button class="layui-btn layui-btn-sm layui-bg-green" onclick="card.transfer(' + JSON.stringify(d).replace(/"/g, '&quot;') + ');">转账</button>';
                    }
                    return html;
                }
            }
        ]]
    });
    $('#card-search').click(function () {
        var cardNo = $("#card-search-no").val();
        var searchData = {};
        if (cardNo != "") {
            searchData.cardNo = cardNo;
        }
        tableInit.reload({
            where: searchData
            , method: 'post'
            , page: {
                curr: 1
            }
        });
        return false;
    });
});