var user = {
    add: function () {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#user-add-form')
                , type: 1
                , title: '添加用户'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    form.render();
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        $.ajax({
                            url: '/bank/user/add',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('添加成功', function (index) {
                                        location.reload();
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
    },
    addCard: function (obj) {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#user-card-add-form')
                , type: 1
                , title: '增加新卡'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    $('#user-card-add-form input[name="userId"]').val(obj.userId);
                    form.render();
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        $.ajax({
                            url: '/bank/card/add',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('开卡成功', function (index) {
                                        location.reload();
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
    }
};
layui.use(['layer', 'table', 'form'], function () {
    var table = layui.table;
    var $ = layui.$;
    var tableInit = table.render({
        elem: '#user'
        , url: '/bank/user/page'
        , method: 'post'
        , page: true
        , limits: [10, 15, 20]
        , cols: [[
            {field: 'id', title: 'ID', sort: true, fixed: 'left'}
            , {field: 'name', title: '姓名'}
            , {field: 'account', title: '账号'}
            , {field: 'phone', title: '电话'}
            , {
                field: 'sex', title: '性别', templet: function (d) {
                    return d.sex == 1 ? "男" : "女";
                }
            }
            , {field: 'addr', title: '地址'}
            , {field: 'idNo', title: '身份证'}
            , {field: 'cardNum', title: '名下卡数'}
            , {field: 'createTime', title: '创建时间'}
            , {
                field: 'option', title: '操作', templet: function (d) {
                    return '<button class="layui-btn layui-btn-sm" onclick="user.addCard(' + JSON.stringify(d).replace(/"/g, '&quot;') + ');">新开卡</button>';
                }
            }
        ]]
    });

    $('#user-search').click(function () {
        var account = $("#user-search-account").val();
        var name = $("#user-search-name").val();
        var searchData = {};
        if (account != "") {
            searchData.account = account;
        }
        if (name != "") {
            searchData.name = name;
        }
        tableInit.reload({
            where: searchData
            , method: 'post'
            , page: {
                curr: 1
            }
        });
        return false;
    });

    $('#user-add').click(function () {
        user.add();
    });

});