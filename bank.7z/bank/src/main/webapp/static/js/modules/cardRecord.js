layui.use(['layer', 'table', 'form'], function () {
    var table = layui.table;
    var form = layui.form;
    var $ = layui.$;
    var tableInit = table.render({
        elem: '#cardRecord'
        , url: '/bank/cardRecord/page'
        , method: 'post'
        , page: true
        , limits: [10, 15, 20]
        , cols: [[
            {field: 'cardNo', title: '交易卡号', sort: true, fixed: 'left'}
            ,{field: 'amount', title: '交易金额', sort: true, fixed: 'left'}
            , {
                field: 'type', title: '交易类型', templet: function (d) {
                    return d.type == 1 ? "开卡" : d.type == 2 ? "存款" : d.type == 3 ? "取款" : d.type == 4 ? "转入" : d.type == 5 ? "转出" : "-";
                }
            }
            , {field: 'account', title: '操作人'}
            , {field: 'remark', title: '交易备注'}
            , {field: 'createTime', title: '交易时间'}
        ]]
    });

    $('#cardRecord-search').click(function () {
        var cardNo = $("#cardRecord-search-no").val();
        var searchData = {};
        if (cardNo != "") {
            searchData.cardNo = cardNo;
        }
        tableInit.reload({
            where: searchData
            , method: 'post'
            , page: {
                curr: 1
            }
        });
        return false;
    });

});