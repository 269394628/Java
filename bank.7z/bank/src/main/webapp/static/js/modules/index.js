layui.config({
    base: '/bank/static/js/' //假设这是你存放拓展模块的根目录
}).extend({ //设定模块别名
    tab: 'tab'
});
layui.use(['tab', 'layer', 'element'], function () {
    var layer = layui.layer;
    var element = layui.element;
    var $ = layui.$;
    var tab = layui.tab;

    $(".navBar .layui-nav .layui-nav-item a").on("click", function () {
        tab.tabAdd($(this));
    });

    var user = JSON.parse(sessionStorage.getItem("user"));
    $("#index-account").html(user.account);

    $("#index-info").css("display", user.role == 1 ? "none" : "blank");
    $("#index-info").click(function () {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#index-info-edit-form')
                , type: 1
                , title: '修改资料'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                    $.ajax({
                        url: '/bank/user/get',
                        dataType: 'json',
                        type: 'post',
                        success: function (res) {
                            if (res.code == -1) {
                                layer.msg(res.msg);
                            } else {
                                $("#index-info-edit-form [name='id']").val(res.data.id);
                                $("#index-info-edit-form [name='account']").val(res.data.account);
                                $("#index-info-edit-form [name='name']").val(res.data.name);
                                $("#index-info-edit-form [name='idNo']").val(res.data.idNo);
                                $("#index-info-edit-form [name='sex'][value='1']").prop("checked", res.data.sex == 1);
                                $("#index-info-edit-form [name='sex'][value='2']").prop("checked", res.data.sex == 2);
                                $("#index-info-edit-form [name='phone']").val(res.data.phone);
                                $("#index-info-edit-form [name='addr']").val(res.data.addr);
                                form.render();
                            }
                        }
                    });
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        $.ajax({
                            url: '/bank/user/modify',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (res.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('修改成功', function (index) {
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
        return false;
    });


    $("#index-password").click(function () {
        layui.use(['layer', 'form'], function () {
            var layer = layui.layer;
            var form = layui.form;
            var $ = layui.$;
            layer.open({
                content: $('#index-password-form')
                , type: 1
                , title: '修改密码'
                , skin: 'layer-ext-skin'
                , btn: ['确定', '取消']
                , area: '400px'
                , success: function (layero, index) {
                    layero.addClass("layui-form");
                    layero.find('.layui-layer-btn0').attr("lay-filter", "formVerify").attr("lay-submit", "");
                }
                , yes: function (index, layero) {
                    form.on('submit(formVerify)', function (data) {
                        var newPassword = $("#index-password-form [name='newPassword']").val();
                        var password = $("#index-password-form [name='password']").val();
                        if (newPassword != password) {
                            layer.alert("两次密码不一致");
                            return false;
                        }
                        $.ajax({
                            url: '/bank/modifyPassword',
                            dataType: 'json',
                            type: 'post',
                            data: data.field,
                            success: function (res) {
                                if (data.code == -1) {
                                    layer.msg(res.msg);
                                } else {
                                    layer.alert('密码修改成功,请重新登录', function (index) {
                                        window.location.href = "/bank/logout";
                                        layer.close(index);
                                    });
                                }
                            }
                        });
                        return false;
                    });
                }
            });
        });
        return false;
    });

});