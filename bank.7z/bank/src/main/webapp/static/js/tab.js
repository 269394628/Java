var tab = {
    navBar: function (data) {
        var ulHtml = '<ul class="layui-nav layui-nav-tree">';
        for (var i = 0; i < data.length; i++) {
            if (data[i].spread) {
                ulHtml += '<li class="layui-nav-item layui-nav-itemed">';
            } else {
                ulHtml += '<li class="layui-nav-item">';
            }
            if (data[i].children != undefined && data[i].children.length > 0) {
                ulHtml += '<a href="javascript:;">';
                if (data[i].icon != undefined && data[i].icon != '') {
                    ulHtml += '<i class="layui-icon ' + data[i].icon + '" data-icon="' + data[i].icon + '" style="font-size: 18px; padding-right:5px;"></i>';
                }
                ulHtml += '<cite>' + data[i].title + '</cite>';
                ulHtml += '<span class="layui-nav-more"></span>';
                ulHtml += '</a>'
                ulHtml += '<dl class="layui-nav-child">';
                for (var j = 0; j < data[i].children.length; j++) {
                    ulHtml += '<dd><a href="javascript:;" data-url="' + data[i].children[j].href + '">';
                    if (data[i].children[j].icon != undefined && data[i].children[j].icon != '') {
                        ulHtml += '<i class="layui-icon ' + data[i].children[j].icon + '" data-icon="' + data[i].children[j].icon + '" style="font-size: 18px; padding-right:5px;"></i>';
                    }
                    ulHtml += '<cite>' + data[i].children[j].title + '</cite></a></dd>';
                }
                ulHtml += "</dl>"
            } else {
                ulHtml += '<a href="javascript:;" data-url="' + data[i].href + '">';
                if (data[i].icon != undefined && data[i].icon != '') {
                    ulHtml += '<i class="layui-icon ' + data[i].icon + '" data-icon="' + data[i].icon + '" style="font-size: 18px; padding-right:5px;"></i>';
                }
                ulHtml += '<cite>' + data[i].title + '</cite></a>';
            }
            ulHtml += '</li>'
        }
        ulHtml += '</ul>';
        return ulHtml;
    }
};
layui.use(['layer', 'element'], function () {
    var layer = layui.layer;
    var element = layui.element;
    var $ = layui.$;
    var layId;

    var TAB = {
        closed: true,
        openTabNum: 10,
        tabFilter: "tab"
    };

    //显示左侧菜单
    if ($(".navBar").html() == '') {
        var _this = this;
        $.ajax({
            url: '/bank/getMenu',
            type: 'post',
            dataType: 'json',
            async: false,
            success: function (navs) {
                $(".navBar").html(tab.navBar(navs)).height($(window).height() - 230);
                //初始化页面元素
                element.render();
                $(window).resize(function () {
                    $(".navBar").height($(window).height() - 230);
                });
            }
        });
    }

    layui.define(function (exports) {
        var tabIdIndex = 0;
        var obj = {
            //通过title获取lay-id
            getLayId: function (title) {
                $(".layui-tab-title.top-tab li span").each(function () {
                    if ($(this).text() == title) {
                        layId = $(this).parent().attr("lay-id");
                    }
                });
                return layId;
            },
            //通过title判断tab是否存在
            hasTab: function (title) {
                var tabIndex = -1;
                $(".layui-tab-title.top-tab li span").each(function () {
                    if ($(this).text() == title) {
                        tabIndex = 1;
                    }
                });
                return tabIndex;
            },
            //右侧内容tab操作
            tabAdd: function (_this) {
                if (_this.find("i.layui-icon").attr("data-icon") != undefined) {
                    var title = '';
                    if (obj.hasTab(_this.find("cite").text()) == -1 && _this.siblings("dl.layui-nav-child").length == 0) {
                        if ($(".layui-tab-title.top-tab li").length == TAB.openTabNum) {
                            layer.msg('只能同时打开' + TAB.openTabNum + '个选项卡哦。不然系统会卡的！');
                            return;
                        }
                        tabIdIndex++;
                        title += "<span>" + _this.find("cite").text() + "</span>";
                        title += '<i class="layui-icon layui-unselect layui-tab-close" data-id="' + tabIdIndex + '">&#x1006;</i>';
                        element.tabAdd(TAB.tabFilter, {
                            title: title,
                            content: "<iframe src='" + _this.attr("data-url") + "' data-id='" + tabIdIndex + "' id='ifm-" + tabIdIndex + "' frameborder='0'></frame>",
                            id: new Date().getTime()
                        });
                    }
                    //切换一个Tab项
                    element.tabChange(TAB.tabFilter, obj.getLayId(_this.find("cite").text()));
                }
            }

        };
        //输出tab接口
        exports('tab', obj);
    });


    $("body").on("click", ".top-tab li", function () {
        //切换后获取当前窗口的内容
        element.tabChange(TAB.tabFilter, $(this).attr("lay-id")).init();
    })

    //删除tab
    $("body").on("click", ".top-tab li i.layui-tab-close", function () {
        element.tabDelete(TAB.tabFilter, $(this).parent("li").attr("lay-id")).init();
    })

});