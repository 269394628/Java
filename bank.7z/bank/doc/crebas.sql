drop table if exists t_card;

drop table if exists t_card_record;

drop table if exists t_login;

drop table if exists t_user;

/*==============================================================*/
/* Table: t_card                                                */
/*==============================================================*/
create table t_card
(
   id                   int not null auto_increment comment '表ID',
   card_no              varchar(50) comment '卡号',
   cash_out             decimal(9,2) comment '出账',
   cash_in              decimal(9,2) comment '入账',
   user_id              int comment '所属用户',
   state                int comment '状态(0  无效 1 有效)',
   create_time          int comment '开卡时间',
   primary key (id)
);

alter table t_card comment '银行卡';

/*==============================================================*/
/* Table: t_card_record                                         */
/*==============================================================*/
create table t_card_record
(
   id                   int not null auto_increment comment '表ID',
   card_id              int comment '银行卡',
   amount               decimal(9,2) comment '交易金额',
   type                 int comment '交易类型(1 开卡 2 存款 3 取款 4 转入 5 转出)',
   operate_id           int comment '操作人',
   remark               varchar(1000) comment '备注',
   create_time          int comment '交易时间',
   primary key (id)
);

alter table t_card_record comment '银行卡记录';

/*==============================================================*/
/* Table: t_login                                               */
/*==============================================================*/
create table t_login
(
   id                   int not null auto_increment comment '表ID',
   account              varchar(50) comment '账号',
   password             varchar(100) comment '密码',
   role                 int comment '角色(1 管理员 2 用户)',
   state                int comment '状态(0 无效 1 有效)',
   primary key (id)
);

alter table t_login comment '登录表';

/*==============================================================*/
/* Table: t_user                                                */
/*==============================================================*/
create table t_user
(
   id                   int not null auto_increment comment '表ID',
   name                 varchar(20) comment '用户姓名',
   phone                varchar(20) comment '用户电话',
   addr                 varchar(1000) comment '用户地址',
   sex                  int comment '性别',
   id_no                varchar(50) comment '证件号码',
   user_id              int comment '所属用户',
   create_time          int comment '创建时间',
   primary key (id)
);

alter table t_user comment '用户信息';
